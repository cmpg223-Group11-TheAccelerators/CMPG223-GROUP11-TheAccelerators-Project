<?php 
  $firstName = $_POST['firstName'];
  $lastName = $_POST['lastName'];
  $address = $_POST['address'];
  $password = $_POST['password'];
  $phoneNumber = $_POST['phoneNumber'];
  $confirm = $_POST['confirm'];

  //Database connection

  $conn = new mysqli('localHost','root','','easyfood');
  if($conn -> connect_error){
    die('Connection failed : '.$conn->connect_error);
  }else{
    $stmt = $conn->prepare("Insert into customer(firstName, lastName, address, password, phoneNumber, confirm)
    values(?,?,?,?,?,?)");
    $stmt->bind_param("sssiss",$firstName,$lastName,$address,$password,$phoneNumber,$confirm);
    $stmt ->execute();
    echo("registration Successfully...");
    $stmt -> close();
    $conn -> close();
  }
?>